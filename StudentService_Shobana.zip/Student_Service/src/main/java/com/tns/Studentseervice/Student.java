package com.tns.Studentseervice;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Student {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer S_id;
	private String Stud_name;
	private String Stud_dept;
	private String Stud_skills;
	
	public Student() {
		super();
	}
	
	public Student(Integer s_id, String stud_name, String stud_dept, String stud_skills) {
		super();
		S_id = s_id;
		Stud_name = stud_name;
		Stud_dept = stud_dept;
		Stud_skills = stud_skills;
	}
	
	public Integer getS_id() {
		return S_id;
	}
	public void setS_id(Integer s_id) {
		S_id = s_id;
	}
	public String getStud_name() {
		return Stud_name;
	}
	public void setStud_name(String stud_name) {
		Stud_name = stud_name;
	}
	public String getStud_dept() {
		return Stud_dept;
	}
	public void setStud_dept(String stud_dept) {
		Stud_dept = stud_dept;
	}
	public String getStud_skills() {
		return Stud_skills;
	}
	public void setS_skills(String stud_skills) {
		Stud_skills = stud_skills;
	}
	@Override
	public String toString()
	{
		return "Student[Student id:"+S_id+" Student name"+Stud_name+" Student dept"+Stud_dept+" Student skills"+Stud_skills+"]";
	}
}
